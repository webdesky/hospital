<?php 	
		$this->load->view("front/common/header1");
	  	//$this->load->view('admin/common/admin_sidebar');
	  	$this->load->view("front/".$body);
	  	$this->load->view("front/common/footer");   
?>
