<!DOCTYPE html>
<html>
<head>
    <title> Hospital </title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="<?php echo base_url('asset/vendor/bootstrap/css/bootstrap.min.css');?>" rel="stylesheet">
    <link href="<?php echo base_url('asset/dist/css/datepicker.css')?>" rel="stylesheet">
    <link href="<?php echo base_url('asset/jquery-ui.css')?>" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('asset/dist/css/styles.css')?>">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('asset/animate.css')?>">
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
</head>