<?php 	
		$this->load->view("front/common/header");
	  	//$this->load->view('admin/common/admin_sidebar');
	  	$this->load->view("front/".$body);
	  	$this->load->view("front/common/footer");   
?>
